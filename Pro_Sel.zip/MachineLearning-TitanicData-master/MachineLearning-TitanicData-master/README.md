# Machine learning training

**Author: Roberto Lima**

Logistic Regression

Machine Learning Training using Python.

This training was developed on Jupyter Notebook (Anaconda)

https://jupyter.org/install


Libraries used in this training:

- Numpy
- Pandas
- Matplotlib
- Seaborn
- Sklearn

